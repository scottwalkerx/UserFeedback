create table feedback
(
id integer NOT NULL AUTO_INCREMENT,
username VARCHAR(50) NOT NULL,
comment VARCHAR(180),
rating INT,
primary key(id)
);

insert into feedback (username, comment, rating) VALUES ('Becky', 'I thought it was okay...' , 3);
insert into feedback (username, comment, rating) VALUES ('NOTAROBOT', 'BEST MOVIE EVER! YOU HAVE TO WATCH' , 10);
insert into feedback (username, comment, rating) VALUES ('GoHomeRoger', 'CGI couldve been better imo' , 6);
