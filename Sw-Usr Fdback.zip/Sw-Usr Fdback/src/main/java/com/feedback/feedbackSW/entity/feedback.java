package com.feedback.feedbackSW.entity;

import java.util.List;

public class feedback {
	
	private int id;
	private String username;
	private String comment;
	private int rating;
	public feedback() {}
	
    private List<feedback> allFeedback;

	public feedback(int id, String username, String comment, int rating) {
		super();
		this.id = id;
		this.username = username;
		this.comment = comment;
		this.rating = rating;
	}
	public int getId() {
		return id;
	}
	
	public void add(feedback fb) {
	    allFeedback.add(fb);
	    }	
	
	public void setId(int id) {
		this.id = id;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public int getRating() {
		return rating;
	}
	public void setRating(int rating) {
		this.rating = rating;
	}
	@Override
	public String toString() {
		return String.format( " \n feedback [id: " + id + ", username: " + username + ", comment: " + comment + ", rating: " + rating + "]");
	}
	
}
