package com.feedback.feedbackSW;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.feedback.feedbackSW.entity.feedback;

@Controller
public class UserOutputController { // this class is a controller designed to handle POST requests
	

  @RequestMapping(method = RequestMethod.POST, value="/yourFeedback")
	
  @ResponseBody
  public feedback getFeedback(@RequestBody feedback usrFeedback) {
	  System.out.println("Now in getFeedback");
	  feedback fb = new feedback(); 
	  fb.add(usrFeedback);
	
	  fb.setUsername(usrFeedback.getUsername());
	  fb.setComment(usrFeedback.getComment());
	  fb.setRating(usrFeedback.getRating());

	return fb;
	
  }
}
