package com.feedback.feedbackSW;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.feedback.feedbackSW.entity.feedback;
import com.feedback.feedbackSW.jdbcDAO.UserRowMapper;

@Controller
public class UserInputController { // this class is a controller designed to handle GET requests

	@Autowired
	JdbcTemplate jdbcTemplate;
	
	@RequestMapping(method = RequestMethod.GET, value="/feedback/allFeedback")
	//this handles GET requests for /feedback/allFeedback
	//by returning a list of feedback class objects 
	
	@ResponseBody
	public List<feedback> findAll() {
		return jdbcTemplate.query("select * from feedback", 
				new UserRowMapper());				
	};
	
	
}
