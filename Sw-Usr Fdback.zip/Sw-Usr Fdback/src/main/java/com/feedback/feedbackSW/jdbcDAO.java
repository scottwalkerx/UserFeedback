package com.feedback.feedbackSW;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import com.feedback.feedbackSW.entity.feedback;

@Repository
public class jdbcDAO {	
	@Autowired
	JdbcTemplate jdbcTemplate;
	
	static class UserRowMapper implements RowMapper<feedback> {

		@Override
		public feedback mapRow(ResultSet rs, int rowNum) throws SQLException {
			feedback feedback = new feedback();
			feedback.setUsername(rs.getString("id"));
			feedback.setComment(rs.getString("comment"));
			feedback.setRating(rs.getInt("rating"));
	
			return feedback;
		}		
	}
	
	public List<feedback> findAll() {
		return jdbcTemplate.query("select * from feedback", 
				new UserRowMapper());				
	};
	
}

